<html>
<head></head>

<body>

<?php 

	echo 'Title:' . $book->title . '<br/>';
	echo 'Author:' . $book->author . '<br/>';
	echo 'Description:' . $book->description . '<br/>';

?>

</body>
</html>