html5-notification
==================

This is implementation of Desktop notification of web apps like Gmail and Facebook.


