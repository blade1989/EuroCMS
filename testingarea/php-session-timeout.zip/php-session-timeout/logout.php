<?php
session_start();
session_destroy();
?>
<p>You have to successfully logged out now.. just go to previous tab/window to see the session timeout alert </p>